import socket

def ipfound():
	error404 = "Bir İp Adresi Bulunamadı (Error-404)"
	try:
		site = input("Site Url: ")
		ip = socket.gethostbyname(site)
		host = socket.getfqdn(ip)
		print(host)
		print(ip)
		
	except:
		print(error404)
		
ipfound()

