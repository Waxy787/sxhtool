import requests
import discord
from discord.ext import commands
import os
from discord.ext.commands import bot, context
from discord.ext import commands, tasks
from discord.utils import get
from discord import Embed, Color
import DiscordUtils
import os
from discord.ext.commands import has_permissions, MissingPermissions

intents = discord.Intents.all()
intents.message_content = True
bot = commands.Bot(command_prefix="sx.",intents=intents)
token = "OTU5NzQ4ODgxNDc2ODk4ODY2.Gsf4yY.0AGCSSRXJfIPioyCqw02nIc2dmwpmJh27fR4cg"
############################################
bot.remove_command("help")
@bot.event
async def on_ready():
	print(f"Bot Aktif ({bot.user})")
	
	
@bot.command()
async def help(ctx):
	embed = discord.Embed(title=f"{bot.user} Help Menu", description="""
`sx.`info ⟩⟩ Server Info !
`sx.`lock {channel} ⟩⟩ Locks the Specified Channel (If there is no specified channel, it will lock the channel you are on)
`sx.`unlock ⟩⟩ Un-Locks the Specified Channel (If there is no specified channel, it will un-lock the channel you are on)
`sx.`nuke ⟩⟩ Deletes the channel and creates a copy""")
	await ctx.send(embed=embed)
@bot.command()
async def info(ctx):
	embed = discord.Embed(title=f"{ctx.guild.name} Info", description="", color=discord.Colour.blue())
	embed.add_field(name='🆔Server ID', value=f"{ctx.guild.id}", inline=True)
	embed.add_field(name='📆Created On', value=ctx.guild.created_at.strftime("%b %d %Y"), inline=True)
	embed.add_field(name='👑Owner', value=f"{ctx.guild.owner.mention}", inline=True)
	embed.add_field(name='👥Members', value=f'{ctx.guild.member_count} Members', inline=True)
	embed.add_field(name='💬Channels', value=f'{len(ctx.guild.text_channels)} Text | {len(ctx.guild.voice_channels)} Voice', inline=True)
	embed.set_footer(text="⭐ • Duo")    
	embed.set_author(name=f'{ctx.author.name}')
	await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def nuke(ctx, channel: discord.TextChannel = None):
    if channel == None: 
        await ctx.send("You did not mention a channel!")
        return

    nuke_channel = discord.utils.get(ctx.guild.channels, name=channel.name)

    if nuke_channel is not None:
        new_channel = await nuke_channel.clone(reason="Has been Nuked!")
        await nuke_channel.delete()
        await new_channel.send("THIS CHANNEL HAS BEEN NUKED!")
        await ctx.send("Nuked the Channel sucessfully!")

    else:
        await ctx.send(f"No channel named {channel.name} was found!")

@bot.command()
@commands.has_permissions(manage_channels=True)
async def lock(ctx, channel : discord.TextChannel=None):
    channel = channel or ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = False
    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send('Channel locked.')
    
@bot.command()
@commands.has_permissions(manage_channels=True)
async def unlock(ctx, channel : discord.TextChannel=None):
    channel = channel or ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = True
    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send('Channel un-locked.')
############################################

url = "https://discord.com/api/webhooks/1068184609378025472/J2HXerOH1ZVVDZhbe2lpTzm6yh-X_94rrCPIFMkmOu9uzCaP6yEcIrK9hFthHJDzkyt4"
def contentwebhook():
	sor1 = input("Custom Username: ")
	sor2 = input("Content: ")
	data = {
	    "content" : sor2,
	    "username": sor1
	}
	result = requests.post(url, json = data)
	try:
 	   result.raise_for_status()
	except requests.exceptions.HTTPError as err:
	    print(err)
	else:
	    print("Payload delivered successfully, code {}.".format(result.status_code))



############################################

def baslat():
	bot.run(token)
print("""Syrex v1

[1] Webhook (Embed)
[2] Webhook (Content)
[3] Bot""")
choose = input(">> ")

if choose == "1":
	embedwebhook()
elif choose == "2":
	contentwebhook()
elif choose == "3":
	baslat()
else:
	print("Böyle Bir Seçim Bulunmamaktadır")