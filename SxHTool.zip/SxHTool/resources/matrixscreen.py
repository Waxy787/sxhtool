import os

os.system("pymatrix-rain")