print("""

░██████╗██╗░░██╗██╗░░██╗████████╗░█████╗░░█████╗░██╗░░░░░
██╔════╝╚██╗██╔╝██║░░██║╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░
╚█████╗░░╚███╔╝░███████║░░░██║░░░██║░░██║██║░░██║██║░░░░░
░╚═══██╗░██╔██╗░██╔══██║░░░██║░░░██║░░██║██║░░██║██║░░░░░
██████╔╝██╔╝╚██╗██║░░██║░░░██║░░░╚█████╔╝╚█████╔╝███████╗
╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝""")

print("""
[1] DDoS            [2] IpFounder
[3] MatrixScreen    [4] EndlossPanel""")
def sor():
	global q
	q = input(">> ")
	
	if q == "1":
		import resources.ddosattack
	elif q == "2":
		import resources.ipfounder
	elif q == "3":
		import resources.matrixscreen
	elif q == "4":
		import resources.endlosspanel
	else:
		print("Something went wrong! Please Enter a Valid Number")
while True:
	sor()